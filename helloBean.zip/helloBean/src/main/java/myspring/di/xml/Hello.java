package myspring.di.xml;

public class Hello {
	String name;
	prinster printer;
	
	public Hello() {}	
	
	public String sayHello() {
		return "Hello" + name;
	}
}
