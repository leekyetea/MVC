package myspring.di.xml;

public class prinster {

}
