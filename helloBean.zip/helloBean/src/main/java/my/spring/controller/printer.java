package my.spring.controller;

public class printer {

}
