package my.spring.controller;

public class model {

	public void addAttribute(String string, String msg) {
		// TODO Auto-generated method stub
		
	}

}
